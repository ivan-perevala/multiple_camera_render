# SPDX-FileCopyrightText: 2025 Ivan Perevala <ivan95perevala@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

# Scene frame:
def frame_change_pre(*args, **kwargs):
    pass


def frame_change_post(*args, **kwargs):
    pass

# SPDX-FileCopyrightText: 2025 Ivan Perevala <ivan95perevala@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

# Render handlers:
def render_init(*args, **kwargs):
    pass


def render_stats(*args, **kwargs):
    pass


def render_pre(*args, **kwargs):
    pass


def render_post(*args, **kwargs):
    pass


def render_complete(*args, **kwargs):
    pass


def render_write(*args, **kwargs):
    pass


def render_cancel(*args, **kwargs):
    pass

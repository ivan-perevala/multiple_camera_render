# SPDX-FileCopyrightText: 2025 Ivan Perevala <ivan95perevala@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

# Dependency graph:
def depsgraph_update_post(*args, **kwargs):
    pass


def depsgraph_update_pre(*args, **kwargs):
    pass
